#ifndef _q3_h
#define _q3_h

int findMajorityElement(Vector<int> &vec);

#endif
