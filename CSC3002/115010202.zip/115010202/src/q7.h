#ifndef _q7_h
#define _q7_h

void q7();

#endif
