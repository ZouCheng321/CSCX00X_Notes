#ifndef _q1_h
#define _q1_h


void drawHFractal(GWindow &gw, double x, double y, double size, int order);

#endif
