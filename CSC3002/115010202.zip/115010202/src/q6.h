#ifndef _q6_h
#define _q6_h

void q6();

#endif
