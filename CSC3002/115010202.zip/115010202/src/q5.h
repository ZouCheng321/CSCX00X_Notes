#ifndef _q5_h
#define _q5_h

void q5();

#endif
